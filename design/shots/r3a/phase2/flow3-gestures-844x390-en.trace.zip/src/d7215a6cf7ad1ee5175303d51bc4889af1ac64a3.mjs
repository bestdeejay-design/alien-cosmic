import fs from 'node:fs';
import path from 'node:path';
import lambdaChromium from './node_modules/@sparticuz/chromium/build/index.js';
import { chromium } from './node_modules/playwright-core/index.mjs';

process.env.LD_LIBRARY_PATH = ['/tmp/al2023/lib', process.env.LD_LIBRARY_PATH || ''].filter(Boolean).join(':');
const BASE = 'http://127.0.0.1:8138/index.html';
const OUT = '/home/user/alien-cosmic/design/shots/r3a/phase2';
fs.mkdirSync(OUT, { recursive: true });
const executablePath = await lambdaChromium.executablePath();
const liveBrowsers = new Set();
const failures = [];
const flowResults = [];
const assert = (cond, message) => {
  if (!cond) { failures.push(message); console.log('FAIL', message); }
  else console.log('PASS', message);
};
const wait = (page, ms = 300) => page.waitForTimeout(ms);
const touch = async (page, selector, delay = 180) => {
  const el = page.locator(selector).first();
  await el.waitFor({ state: 'visible', timeout: 12000 });
  await el.tap({ timeout: 12000 });
  await wait(page, delay);
};

async function newFlow(name, viewport, { locale = 'ru', quickBattle = null, panel = 'bottom' } = {}) {
  const browser = await chromium.launch({ args: lambdaChromium.args, executablePath, headless: true });
  liveBrowsers.add(browser);
  const context = await browser.newContext({
    viewport, deviceScaleFactor: 1, isMobile: true, hasTouch: true,
  });
  await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.addInitScript(({ locale, quickBattle, panel }) => {
    localStorage.setItem('terranrts.language', locale);
    localStorage.removeItem('terranrts.progress');
    if (quickBattle) {
      if (!localStorage.getItem('terranrts.quickBattle')) localStorage.setItem('terranrts.quickBattle', JSON.stringify(quickBattle));
    } else localStorage.removeItem('terranrts.quickBattle');
    localStorage.setItem('terranrts.panel', JSON.stringify({ pos: panel, hidden: false }));
  }, { locale, quickBattle, panel });
  await page.goto(BASE, { waitUntil: 'load' });
  await page.waitForFunction(() => !!window.game && !!document.querySelector('#btn-quick-primary'), null, { timeout: 12000 });
  await wait(page, 450);
  console.log(`FLOW ${name}: hasTouch=${await page.evaluate(() => navigator.maxTouchPoints > 0)} viewport=${viewport.width}x${viewport.height}`);
  const finish = async () => {
    const trace = path.join(OUT, `${name}.trace.zip`);
    await context.tracing.stop({ path: trace });
    const result = { name, viewport, errors, trace };
    flowResults.push(result);
    if (errors.length) errors.forEach((e) => failures.push(`${name}: ${e}`));
    await context.close();
    await browser.close();
    liveBrowsers.delete(browser);
    return result;
  };
  return { page, context, errors, finish };
}
async function startSaved(page) {
  await touch(page, '#btn-quick-primary', 850);
  await page.waitForFunction(() => window.game && window.game.started, null, { timeout: 15000 });
  await wait(page, 450);
}
async function snap(page, name) { await page.screenshot({ path: path.join(OUT, `${name}.png`), fullPage: false, timeout: 60000, animations: 'disabled' }); }
async function dispatchTouches(cdp, type, points) {
  await cdp.send('Input.dispatchTouchEvent', {
    type,
    touchPoints: points.map((p) => ({ id: p.id, x: p.x, y: p.y, radiusX: 2, radiusY: 2, force: 1 })),
  });
}

try {
  if (['all','1'].includes(process.env.FLOW_FILTER || 'all')) {
  // Flow 1 — first-visit Quick Battle reaches a real battle in three touch taps.
  {
    const f = await newFlow('flow1-quick-battle-3-taps-ru', { width: 390, height: 844 });
    const { page } = f;
    const coarse = await page.evaluate(() => ({
      points: navigator.maxTouchPoints,
      canvasTouch: getComputedStyle(document.querySelector('#game-canvas')).touchAction,
      bodyTouch: getComputedStyle(document.body).touchAction,
    }));
    assert(coarse.points > 0, 'Flow 1 runs with native touch points');
    assert(coarse.canvasTouch === 'none' && coarse.bodyTouch !== 'none', 'canvas gestures are isolated; document scrolling remains enabled');
    // Page touch-scroll must still work outside the game canvas/minimap.
    const cdp = await f.context.newCDPSession(page);
    const beforeScroll = await page.evaluate(() => window.scrollY);
    await dispatchTouches(cdp, 'touchStart', [{ id: 80, x: 350, y: 730 }]);
    await wait(page, 80);
    await dispatchTouches(cdp, 'touchMove', [{ id: 80, x: 350, y: 300 }]);
    await wait(page, 120);
    await dispatchTouches(cdp, 'touchEnd', []);
    await wait(page, 350);
    const afterScroll = await page.evaluate(() => window.scrollY);
    assert(afterScroll > beforeScroll, `touch scroll outside game remains enabled (${beforeScroll}→${afterScroll})`);
    await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
    await wait(page, 250);
    let taps = 0;
    await touch(page, '#btn-quick-primary', 650); taps++;
    await touch(page, '#quick-faction-human', 200); taps++;
    await touch(page, '#btn-quick-battle-start', 900); taps++;
    await page.waitForFunction(() => window.game && window.game.started, null, { timeout: 12000 });
    const started = await page.evaluate(() => ({
      started: game.started, map: [game.state.map.w, game.state.map.h],
      faction: game.state.factions.player, hasTouch: navigator.maxTouchPoints > 0,
      zoomVisible: !document.querySelector('#zoom-controls').hidden,
      zoom: document.querySelector('#zoom-value').textContent,
    }));
    assert(started.started && taps <= 3 && started.map[0] === 64 && started.map[1] === 64 && started.faction === 'human',
      `first-visit battle starts in ${taps} taps on default 64×64 / HELIOS`);
    assert(started.zoomVisible, 'visible +/− and zoom indicator appear in battle');
    await snap(page, 'flow1-battle-start-390x844');
    await f.finish();
  }

  }
  if (['all','2'].includes(process.env.FLOW_FILTER || 'all')) {
  // Flow 2 — touch select/build, switch type in placement, failure toast and ghost-side cancel.
  {
    const f = await newFlow('flow2-placement-switch-cancel-ru', { width: 390, height: 844 }, {
      quickBattle: { presetId: 'square-64', faction: 'human' },
    });
    const { page } = f;
    await startSaved(page);
    const worker = await page.evaluate(() => {
      const u = game.state.units.find((x) => x.side === 'player' && x.type === 'worker' && !x.dead);
      const p = game.worldToScreen(u.x, u.y);
      return { id: u.id, x: p.x, y: p.y, type: u.type };
    });
    await page.touchscreen.tap(worker.x, worker.y);
    await wait(page, 300);
    const selected = await page.evaluate((id) => game.state.selection.some((x) => x.id === id), worker.id);
    assert(selected, 'touch tap selects a friendly worker');
    await touch(page, '#cmd-grid button[data-code="KeyB"]', 180);
    await touch(page, '#cmd-grid button[data-code="KeyY"]', 180); // wall
    const placingWall = await page.evaluate(() => game.state.placing && game.state.placing.type);
    assert(placingWall === 'wall', 'touch enters wall placement');
    await touch(page, '#cmd-grid button[data-code="KeyQ"]', 180); // switch to CC even with insufficient minerals
    const switched = await page.evaluate(() => ({
      type: game.state.placing && game.state.placing.type,
      selected: !!document.querySelector('#cmd-grid button[data-code="KeyQ"]')?.classList.contains('is-selected'),
      cost: game.state.minerals.player,
    }));
    assert(switched.type === 'cc' && switched.selected, 'placement palette switches building type and marks active type');
    // Center on the friendly HQ, then try to place over it: preserves the existing failure toast.
    const target = await page.evaluate(() => {
      const b = game.state.buildings.find((x) => x.side === 'player' && x.type === 'cc' && !x.dead);
      const wx = (b.tx + b.w / 2) * 32, wy = (b.ty + b.h / 2) * 32;
      const sx = Math.max(game.uiLeft + 80, Math.min(game.cssW - game.uiRight - 40, 220));
      const sy = Math.max(game.uiTop + 36, 180);
      game.state.camera.x = wx - sx / game.state.camera.z;
      game.state.camera.y = wy - sy / game.state.camera.z;
      game.clampCam();
      const p = game.worldToScreen(wx, wy);
      return { x: p.x, y: p.y, target: [wx, wy], insets: [game.uiTop, game.uiBottom] };
    });
    await page.touchscreen.tap(target.x, target.y);
    await wait(page, 300);
    const failure = await page.evaluate(() => ({
      placing: game.state.placing && game.state.placing.type,
      toast: [...document.querySelectorAll('#toasts .toast')].map((x) => x.textContent.trim()),
      cancelHidden: document.querySelector('#placement-cancel').hidden,
      cancelRect: document.querySelector('#placement-cancel').getBoundingClientRect().toJSON(),
    }));
    assert(failure.placing === 'cc' && failure.toast.length > 0,
      `invalid placement preserves failure toast and keeps ghost active (${failure.toast.join(' | ')})`);
    assert(!failure.cancelHidden && failure.cancelRect.width >= 44 && failure.cancelRect.height >= 44,
      'ghost-side placement ✕ is visible and meets the 44px target floor');
    await snap(page, 'flow2-placement-failure-and-cancel-390x844');
    await touch(page, '#placement-cancel', 300);
    const cancelled = await page.evaluate(() => game.state.placing === null);
    assert(cancelled, 'touching ghost-side ✕ cancels placement');
    await snap(page, 'flow2-placement-cancelled-390x844');
    await f.finish();
  }

  }
  if (['all','3'].includes(process.env.FLOW_FILTER || 'all')) {
  // Flow 3 — empty-space pan, anchored pinch, minimap capture/drag, long-press arbitration.
  {
    const f = await newFlow('flow3-gestures-844x390-en', { width: 844, height: 390 }, {
      locale: 'en', quickBattle: { presetId: 'square-64', faction: 'human' },
    });
    const { page } = f;
    await startSaved(page);
    await page.evaluate(() => { window.__r3aOriginalTick = game.tick; game.tick = () => {}; });
    await page.evaluate(() => {
      const g = game, st = g.state;
      st.camera.x = Math.max(0, (st.map.pxW - g.visW()) / 2);
      st.camera.y = Math.max(0, (st.map.pxH - g.visH()) / 2);
      g.clampCam();
    });
    const cdp = await f.context.newCDPSession(page);
    const empty = await page.evaluate(() => {
      const g = game, st = g.state;
      const blocked = (x, y) => {
        const w = g.screenToWorld(x, y);
        if (st.units.some((u) => !u.dead && !u.garrison && Math.hypot(u.x - w.x, u.y - w.y) < 30)) return true;
        if (st.buildings.some((b) => !b.dead && w.x >= b.tx * 32 && w.x < (b.tx + b.w) * 32 && w.y >= b.ty * 32 && w.y < (b.ty + b.h) * 32)) return true;
        return false;
      };
      for (let y = Math.max(g.uiTop + 34, 92); y < g.cssH - g.uiBottom - 16; y += 14) {
        for (let x = 220; x < g.cssW - 20; x += 18) if (!blocked(x, y)) return { x, y };
      }
      return { x: 520, y: 130 };
    });
    const panBefore = await page.evaluate(() => ({ ...game.state.camera }));
    await dispatchTouches(cdp, 'touchStart', [{ id: 1, ...empty }]);
    await wait(page, 90);
    await dispatchTouches(cdp, 'touchMove', [{ id: 1, x: empty.x + 55, y: empty.y + 17 }]);
    await wait(page, 100);
    await dispatchTouches(cdp, 'touchEnd', []);
    await wait(page, 250);
    const panAfter = await page.evaluate(() => ({ ...game.state.camera }));
    assert(Math.abs(panAfter.x - panBefore.x) > 8 || Math.abs(panAfter.y - panBefore.y) > 8,
      'one-finger empty-terrain swipe pans the game camera');

    const pinchPoint = { x: 550, y: Math.max(90, Math.min(160, empty.y)) };
    const pinchBefore = await page.evaluate(({ x, y }) => {
      const z = game.state.camera.z || 1;
      return { z, worldX: game.state.camera.x + x / z, worldY: game.state.camera.y + y / z, viewportScale: visualViewport.scale };
    }, pinchPoint);
    await dispatchTouches(cdp, 'touchStart', [
      { id: 2, x: pinchPoint.x - 45, y: pinchPoint.y },
      { id: 3, x: pinchPoint.x + 45, y: pinchPoint.y },
    ]);
    await wait(page, 100);
    await dispatchTouches(cdp, 'touchMove', [
      { id: 2, x: pinchPoint.x - 72, y: pinchPoint.y },
      { id: 3, x: pinchPoint.x + 72, y: pinchPoint.y },
    ]);
    await wait(page, 130);
    await dispatchTouches(cdp, 'touchEnd', []);
    await wait(page, 250);
    const pinchAfter = await page.evaluate(({ x, y }) => {
      const z = game.state.camera.z || 1;
      return { z, worldX: game.state.camera.x + x / z, worldY: game.state.camera.y + y / z, viewportScale: visualViewport.scale };
    }, pinchPoint);
    assert(pinchAfter.z > pinchBefore.z + 0.1 && Math.abs(pinchAfter.viewportScale - 1) < 0.01,
      `pinch zooms the game, not the browser (${pinchBefore.z.toFixed(2)}→${pinchAfter.z.toFixed(2)}, viewport=${pinchAfter.viewportScale})`);
    assert(Math.hypot(pinchAfter.worldX - pinchBefore.worldX, pinchAfter.worldY - pinchBefore.worldY) < 3,
      'pinch zoom remains anchored at its midpoint');
    await touch(page, '#zoom-in', 180);
    await touch(page, '#zoom-out', 180);
    const zoomButton = await page.locator('#zoom-value').textContent();
    assert(/\d+%/.test(zoomButton || ''), 'visible zoom indicator updates after +/− buttons');

    const mm = await page.locator('#minimap').boundingBox();
    const beforeMiniTap = await page.evaluate(() => ({ ...game.state.camera }));
    await page.touchscreen.tap(mm.x + mm.width * 0.78, mm.y + mm.height * 0.72);
    await wait(page, 250);
    const afterMiniTap = await page.evaluate(() => ({ ...game.state.camera }));
    assert(Math.abs(afterMiniTap.x - beforeMiniTap.x) > 2 || Math.abs(afterMiniTap.y - beforeMiniTap.y) > 2,
      'touch tap on minimap recenters the camera');
    const mmRect = await page.locator('#minimap').boundingBox();
    const dragA = { x: mmRect.x + mmRect.width * 0.25, y: mmRect.y + mmRect.height * 0.5 };
    const dragB = { x: mmRect.x + mmRect.width * 0.78, y: dragA.y };
    const beforeMiniDrag = await page.evaluate(() => ({ ...game.state.camera }));
    await dispatchTouches(cdp, 'touchStart', [{ id: 4, ...dragA }]);
    await wait(page, 80);
    await dispatchTouches(cdp, 'touchMove', [{ id: 4, x: (dragA.x + dragB.x) / 2, y: dragA.y }]);
    await wait(page, 70);
    await dispatchTouches(cdp, 'touchMove', [{ id: 4, ...dragB }]);
    await wait(page, 70);
    await dispatchTouches(cdp, 'touchEnd', []);
    await wait(page, 220);
    const afterMiniDrag = await page.evaluate(() => ({ ...game.state.camera }));
    assert(Math.abs(afterMiniDrag.x - beforeMiniDrag.x) > 2 || Math.abs(afterMiniDrag.y - beforeMiniDrag.y) > 2,
      'minimap pointer-capture drag continuously moves the camera');

    // A drag beginning on a friendly unit remains box-select, not camera pan.
    const boxPair = await page.evaluate(() => {
      const g=game, st=g.state, live=st.units.filter(u=>u.side==='player'&&!u.dead&&!u.garrison);
      if(live.length<2) return null;
      st.camera.x=Math.max(0,(st.map.pxW-g.visW())/2); st.camera.y=Math.max(0,(st.map.pxH-g.visH())/2); g.clampCam();
      const inBuilding=(w)=>st.buildings.some(b=>!b.dead&&w.x>=b.tx*32&&w.x<(b.tx+b.w)*32&&w.y>=b.ty*32&&w.y<(b.ty+b.h)*32);
      let open=null;
      for(let y=g.uiTop+18;y<g.cssH-g.uiBottom-25&&!open;y+=12) for(let x=180;x<g.cssW-60;x+=18){const w=g.screenToWorld(x,y);const clear=live.every(u=>Math.hypot(u.x-w.x,u.y-w.y)>90);if(w.x>25&&w.y>25&&w.x<st.map.pxW-80&&w.y<st.map.pxH-80&&clear&&!inBuilding(w)){open={x,y,w};break;}}
      if(!open) return null;
      const a=live[0],b=live[1],offset=Math.max(40,36/(st.camera.z||1));
      for(const u of [a,b]){u.order={kind:'idle'};u.path=null;u.pathI=0;u.moveDir=null;u.moving=false;u.waitT=0;}
      a.x=open.w.x;a.y=open.w.y;a.prevX=a.x;a.prevY=a.y;
      b.x=open.w.x+offset;b.y=open.w.y+offset*.65;b.prevX=b.x;b.prevY=b.y;
      const start=g.worldToScreen(a.x,a.y),end=g.worldToScreen(b.x,b.y);
      return {start,end:{x:end.x+8,y:end.y+8},ids:[a.id,b.id]};
    });
    assert(!!boxPair, 'friendly box-select fixture has two reachable units');
    await dispatchTouches(cdp, 'touchStart', [{ id: 9, ...boxPair.start }]);
    await wait(page, 80);
    await dispatchTouches(cdp, 'touchMove', [{ id: 9, ...boxPair.end }]);
    await wait(page, 100);
    await dispatchTouches(cdp, 'touchEnd', []);
    await wait(page, 180);
    const boxSelected = await page.evaluate(ids=>ids.every(id=>game.state.selection.some(u=>u.id===id)),boxPair.ids);
    assert(boxSelected, 'drag beginning on a friendly unit box-selects the enclosed units');

    // Instrument only the existing RMB hook so the event path is observable.
    await page.evaluate(() => {
      window.__rmbCount = 0;
      const original = game.hooks.issueRMB;
      game.hooks.issueRMB = (...args) => { window.__rmbCount++; (window.__rmbTimes ||= []).push(performance.now()); return original(...args); };
      const u = game.state.units.find((x) => x.side === 'player' && x.type === 'worker' && !x.dead);
      const sx = game.cssW / 2, sy = game.uiTop + 55;
      game.state.camera.x = u.x - sx / game.state.camera.z;
      game.state.camera.y = u.y - sy / game.state.camera.z;
      game.clampCam();
    });
    const longPressTarget = await page.evaluate(() => {
      const g = game, st = g.state;
      const candidates = [[g.cssW * .72, g.uiTop + 85], [g.cssW * .62, g.uiTop + 120], [g.cssW * .78, g.uiTop + 55]];
      for (const [x,y] of candidates) {
        const w = g.screenToWorld(x,y);
        if (!st.units.some(u => !u.dead && Math.hypot(u.x-w.x,u.y-w.y)<35) &&
            !st.buildings.some(b => !b.dead && w.x>=b.tx*32&&w.x<(b.tx+b.w)*32&&w.y>=b.ty*32&&w.y<(b.ty+b.h)*32)) return {x,y};
      }
      return {x:g.cssW*.72,y:g.uiTop+80};
    });
    const workerScreen = await page.evaluate(() => {
      const u = game.state.units.find((x) => x.side === 'player' && x.type === 'worker' && !x.dead);
      const p = game.worldToScreen(u.x,u.y); return {x:p.x,y:p.y,id:u.id};
    });
    await page.touchscreen.tap(workerScreen.x, workerScreen.y);
    await wait(page, 120);
    await dispatchTouches(cdp, 'touchStart', [{ id: 5, ...longPressTarget }]);
    await wait(page, 500);
    const longCount = await page.evaluate(() => window.__rmbCount);
    await dispatchTouches(cdp, 'touchEnd', []);
    await wait(page, 120);
    assert(longCount === 1, 'stationary ~450ms long-press invokes the RMB-equivalent command once');

    await page.evaluate(() => { window.__rmbCount = 0; });
    await dispatchTouches(cdp, 'touchStart', [{ id: 6, ...longPressTarget }]);
    await wait(page, 110);
    await dispatchTouches(cdp, 'touchMove', [{ id: 6, x: longPressTarget.x + 12, y: longPressTarget.y }]);
    await wait(page, 480);
    const movedCount = await page.evaluate(() => window.__rmbCount);
    await dispatchTouches(cdp, 'touchEnd', []);
    await wait(page, 100); // let implicit pointer capture release settle before the next gesture
    assert(movedCount === 0, 'long-press is canceled after 12px movement');

    await page.evaluate(() => { window.__rmbCount = 0; });
    await dispatchTouches(cdp, 'touchStart', [{ id: 7, ...longPressTarget }]);
    await wait(page, 20);
    await dispatchTouches(cdp, 'touchStart', [
      { id: 7, ...longPressTarget }, { id: 8, x: longPressTarget.x + 70, y: longPressTarget.y },
    ]);
    await wait(page, 500);
    const secondCount = await page.evaluate(() => window.__rmbCount);
    await dispatchTouches(cdp, 'touchEnd', []);
    console.log('SECOND TIMINGS',JSON.stringify({secondCount,rmbTimes:await page.evaluate(()=>window.__rmbTimes),events:await page.evaluate(()=>window.__r3aEvents)}));
    assert(secondCount === 0, 'a second pointer cancels the pending long-press');
    await page.evaluate(() => { if (window.__r3aOriginalTick) { game.tick = window.__r3aOriginalTick; delete window.__r3aOriginalTick; } });
    await snap(page, 'flow3-gestures-844x390');
    await f.finish();
  }

  }
  if (['all','4'].includes(process.env.FLOW_FILTER || 'all')) {
  // Flow 4 — panel insets × 3 requested viewports, short-landscape shelf, minimap aspects,
  // RU/EN controls, modal chrome, end-action availability, and target size audit.
  {
    const f = await newFlow('flow4-responsive-locales-modals-ru', { width: 390, height: 844 }, {
      quickBattle: { presetId: 'square-64', faction: 'human' },
    });
    const { page } = f;
    await startSaved(page);
    const layout = async (label) => {
      const m = await page.evaluate(() => {
        const g = game, p = document.querySelector('#bottom-panel'), top = document.querySelector('#topbar');
        const b = p.getBoundingClientRect();
        const classes = document.body.classList;
        const pos = classes.contains('panel-left') ? 'left' : classes.contains('panel-right') ? 'right' : classes.contains('panel-top') ? 'top' : 'bottom';
        return {
          width: innerWidth, height: innerHeight, pos,
          panel: { x:b.x, y:b.y, w:b.width, h:b.height, scrollW:p.scrollWidth, clientW:p.clientWidth },
          topbar: { h:top.offsetHeight, scrollW:top.scrollWidth, clientW:top.clientWidth },
          insets: { top:g.uiTop, bottom:g.uiBottom, left:g.uiLeft, right:g.uiRight },
          compactToggle: getComputedStyle(document.querySelector('#panel-compact-toggle')).display,
          minimap: { box:document.querySelector('#minimap-box').getBoundingClientRect().toJSON(), bitmap:[document.querySelector('#minimap').width,document.querySelector('#minimap').height] },
          targets: ['#btn-sound','#btn-pause','#btn-restart','#btn-exit','#panel-pos','#panel-hide','#panel-compact-toggle'].map(s=>{const e=document.querySelector(s),r=e.getBoundingClientRect();return {s,w:r.width,h:r.height,display:getComputedStyle(e).display};}),
        };
      });
      const expected = m.pos === 'left'
        ? m.insets.left === Math.round(m.panel.w) && m.insets.right === 0 && m.insets.top === m.topbar.h
        : m.pos === 'right'
          ? m.insets.right === Math.round(m.panel.w) && m.insets.left === 0 && m.insets.top === m.topbar.h
          : m.pos === 'top'
            ? m.insets.top === Math.round(m.panel.h) + m.topbar.h && m.insets.bottom === 0
            : m.insets.bottom === Math.round(m.panel.h) && m.insets.top === m.topbar.h;
      assert(expected, `${label}: ${m.pos} panel insets match measured DOM (${JSON.stringify(m.insets)} / ${m.panel.w}×${m.panel.h})`);
      assert(m.topbar.scrollW <= m.topbar.clientW + 1, `${label}: topbar fits within viewport`);
      for (const t of m.targets) if (t.display !== 'none' && t.w > 0 && t.h > 0)
        assert(t.w >= 44 && t.h >= 44, `${label}: ${t.s} is >=44px (${t.w.toFixed(1)}×${t.h.toFixed(1)})`);
      return m;
    };
    const viewports = [[390,844],[844,390],[360,740]];
    for (const [width,height] of viewports) {
      await page.setViewportSize({ width, height });
      await wait(page, 350);
      // Four positions from the current stored position; four taps return to it.
      for (let i = 0; i < 4; i++) {
        await touch(page, '#panel-pos', 180);
        const m = await layout(`panel-cycle-${width}x${height}-${i+1}`);
        await snap(page, `layout-${m.pos}-${width}x${height}`);
      }
    }

    await page.setViewportSize({ width: 844, height: 390 });
    await wait(page, 350);
    const compactBefore = await layout('short-landscape-compact');
    assert(compactBefore.compactToggle !== 'none', 'short landscape exposes reversible compact-shelf control');
    const compactH = compactBefore.panel.h;
    await touch(page, '#panel-compact-toggle', 280);
    const expanded = await layout('short-landscape-expanded');
    assert(expanded.panel.h > compactH, `compact shelf expands to reveal information (${compactH}→${expanded.panel.h}px)`);
    await touch(page, '#panel-compact-toggle', 280);
    await layout('short-landscape-collapsed');
    await touch(page, '#btn-pause', 220);
    const pause = await page.evaluate(() => {
      const r=document.querySelector('#pause-overlay').getBoundingClientRect();
      return {r:r.toJSON(), top:game.uiTop,bottom:game.uiBottom,left:game.uiLeft,right:game.uiRight, hidden:document.querySelector('#pause-overlay').classList.contains('hidden')};
    });
    const pauseViewportHeight = await page.evaluate(() => innerHeight);
    assert(!pause.hidden && Math.abs(pause.r.y-pause.top)<1 && Math.abs(pause.r.bottom-(pauseViewportHeight-pause.bottom))<1,
      'pause overlay covers only the unobscured playfield in 844×390');
    await snap(page, 'layout-pause-844x390');
    await touch(page, '#btn-pause', 180);

    // Width guardrails on narrower, tablet-ish, and desktop layouts.
    for (const [width,height] of [[320,720],[720,900],[1280,800]]) {
      await page.setViewportSize({ width, height }); await wait(page, 280);
      const m = await layout(`width-${width}`);
      assert(m.topbar.scrollW <= m.topbar.clientW + 1, `topbar has no horizontal overflow at ${width}px`);
    }

    // Map-aspect tests: save a preset, reload, and touch-launch each battle.
    for (const preset of ['wide-96x64','tall-64x96']) {
      await page.evaluate((preset) => {
        localStorage.setItem('terranrts.quickBattle', JSON.stringify({ presetId: preset, faction: 'human' }));
        localStorage.setItem('terranrts.panel', JSON.stringify({ pos:'bottom', hidden:false }));
      }, preset);
      await page.reload({ waitUntil:'load' }); await wait(page, 250);
      await touch(page, '#btn-quick-primary', 850);
      await page.waitForFunction(() => game && game.started, null, { timeout:12000 });
      const mapAspect = await page.evaluate(() => {
        const m=game.state.map, box=document.querySelector('#minimap-box').getBoundingClientRect(), c=document.querySelector('#minimap');
        return {map:[m.w,m.h], mapAspect:m.pxW/m.pxH, boxAspect:box.width/box.height, bitmapAspect:c.width/c.height};
      });
      assert(Math.abs(mapAspect.mapAspect-mapAspect.boxAspect)<0.04 && Math.abs(mapAspect.mapAspect-mapAspect.bitmapAspect)<0.01,
        `${preset}: minimap box and bitmap match map aspect (${mapAspect.mapAspect.toFixed(3)})`);
      await snap(page, `minimap-${preset}`);
    }

    // Home control exposes the accessible Controls disclosure; RU/EN touch strings stay in parity.
    await page.evaluate(() => game.toMenu()); await wait(page, 300);
    await touch(page, '#menu-controls summary', 120);
    const ruHelp = await page.locator('#menu-controls .help').innerText();
    assert(ruHelp.includes('450 мс') && ruHelp.includes('pinch') && ruHelp.includes('✕'), 'RU Controls include long-press, pinch and placement alternatives');
    await page.locator('#lang-select').selectOption('en'); await wait(page, 250);
    const enHelp = await page.locator('#menu-controls .help').innerText();
    assert(enHelp.includes('450ms') && enHelp.includes('pinch') && enHelp.includes('✕'), 'EN Controls include long-press, pinch and placement alternatives');
    await page.locator('#lang-select').selectOption('ru'); await wait(page, 220);

    // Modal chrome is hidden while a screen is active; end screen keeps Home/Replay and conditional Next.
    await page.evaluate(async () => {
      const ui = await import('./js/ui.js');
      ui.showMissions(game);
    }); await wait(page, 220);
    const missionModal = await page.evaluate(() => ({
      open:!document.querySelector('#mission-overlay').classList.contains('hidden'),
      chrome:getComputedStyle(document.querySelector('#topbar')).visibility,
      panel:getComputedStyle(document.querySelector('#bottom-panel')).visibility,
      body:document.body.classList.contains('screen-modal-open'),
    }));
    assert(missionModal.open && missionModal.body && missionModal.chrome === 'hidden' && missionModal.panel === 'hidden',
      'campaign modal dims content and suppresses inert game chrome');
    await page.evaluate(async () => { const ui = await import('./js/ui.js'); ui.hideMissions(); });
    await page.evaluate(async () => {
      const [{showEnd},{MISSIONS}] = await Promise.all([import('./js/ui.js'),import('./js/missions.js')]);
      showEnd(false, game.state.stats);
    }); await wait(page, 180);
    let end = await page.evaluate(() => ({
      home:!document.querySelector('#btn-end-home').hidden && document.querySelector('#btn-end-home').getBoundingClientRect().width >= 44,
      replay:!document.querySelector('#btn-again').hidden && document.querySelector('#btn-again').getBoundingClientRect().width >= 44,
      nextHidden:document.querySelector('#btn-next').hidden,
      chrome:getComputedStyle(document.querySelector('#topbar')).visibility,
    }));
    assert(end.home && end.replay && end.nextHidden && end.chrome === 'hidden', 'end screen always shows Home + Replay, hides Next unless pendingNext');
    await snap(page, 'flow4-end-home-replay');
    await touch(page, '#btn-again', 450);
    assert(await page.evaluate(() => game.started), 'Replay action restarts the battle');
    await page.evaluate(() => game.toMenu()); await wait(page, 180);
    await page.evaluate(async () => {
      const [ui, {MISSIONS}] = await Promise.all([import('./js/ui.js'),import('./js/missions.js')]);
      ui.hideStart();
      ui.showEnd(true, game.state.stats, { next: MISSIONS[1] });
    }); await wait(page, 180);
    end = await page.evaluate(() => ({ nextHidden:document.querySelector('#btn-next').hidden, nextDisabled:document.querySelector('#btn-next').disabled }));
    assert(!end.nextHidden && !end.nextDisabled, 'Next action appears only when pendingNext is provided');
    await snap(page, 'flow4-end-next');
    await touch(page, '#btn-next', 250);
    assert(await page.evaluate(() => !document.querySelector('#brief-overlay').classList.contains('hidden')),
      'conditional Next opens the next mission briefing');
    await f.finish();
  }
  }
} catch (e) {
  failures.push('FATAL: ' + (e?.stack || String(e)));
  console.error('FATAL', e?.stack || e);
} finally {
  await Promise.all([...liveBrowsers].map((browser) => browser.close().catch(() => {})));
}

console.log('\nFLOW SUMMARY');
for (const r of flowResults) console.log(JSON.stringify({ name:r.name, errors:r.errors, trace:r.trace }));
if (failures.length) {
  console.log(`\nR3-A PHASE 2 BROWSER FAILURES (${failures.length})`);
  failures.forEach((x) => console.log(' - ' + x));
  process.exitCode = 1;
} else {
  console.log(`\nR3-A PHASE 2 BROWSER: ${flowResults.length} touch flows passed; 0 page/console errors`);
}
